document.addEventListener('DOMContentLoaded', function () {
  document.querySelector('HEADER').style.color = '#FF0000';
});
