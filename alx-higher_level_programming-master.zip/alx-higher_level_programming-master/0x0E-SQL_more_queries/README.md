# MORE QUERIES.
This task is a continuation of SQL task
