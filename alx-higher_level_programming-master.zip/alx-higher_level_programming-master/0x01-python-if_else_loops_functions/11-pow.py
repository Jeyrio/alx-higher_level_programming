#!/usr/bin/python3

def pow(a, b):
    return (a ** b)
