-- Prints the full description of the table first_table in my MySQL server.
SHOW CREATE TABLE `first_table`;
