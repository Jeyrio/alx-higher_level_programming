-- Lists all rows of the table first_table in my MySQL server.
SELECT * FROM `first_table`;
